// ═══════════════════════════════════════════════════════
// src/balances/balances.js
// Módulo de estadísticas y balances:
//   - repCatIndex              (índice armario→categoría)
//   - buildBienCard            (card bienes de cambio/uso)
//   - buildYearMinCard / saveYearMinSnapshot (histórico anual)
//   - _makePieSvg / buildPieCard / setPieMode (gráfico torta)
//   - renderBal                (renderizado completo)
// Depende de: CELLS, movs, storage.js, utils.js,
//             constants.js (BIEN_LABELS, PIE_PALETTE)
// ═══════════════════════════════════════════════════════
'use strict';

function repCatIndex() {
  // mapea id de repisa (ej "A1") -> categoría, por nave
  const idx = { 'N-1':{}, 'N-2':{} };
  ['n1','n2'].forEach(nk => {
    const nv = nk === 'n1' ? 'N-1' : 'N-2';
    const arms = CELLS[nk] || {};
    Object.values(arms).forEach(arm => {
      const reps = (arm && arm.repisas) || {};
      Object.entries(reps).forEach(([rid, r]) => {
        if (r && r.cat && r.cat !== '—') idx[nv][rid] = r.cat;
      });
    });
  });
  return idx;
}


// ════════════════════════════════════════════════
// PIE CHART SVG — categorías por unidades y por valor
// SVG puro, sin dependencias externas.
// ════════════════════════════════════════════════

// ════════════════════════════════════════════════
// BALANCES — Bienes de Cambio/Uso + Año histórico
// ════════════════════════════════════════════════

const BIEN_LABELS = {
  cambio:        'Bienes de Cambio',
  uso:           'Bienes de Uso / Patrimonial',
  sin_clasificar:'Sin clasificar',
};
const BIEN_COLORS = {
  cambio:        'var(--accent)',
  uso:           'var(--amber, #F59E0B)',
  sin_clasificar:'var(--muted)',
};

function buildBienCard(bienStock, fmtM) {
  const keys = Object.keys(bienStock);
  if (!keys.length) return '';
  const fmt = fmtM || function(n){ return '$ '+Number(n||0).toLocaleString('es-AR',{minimumFractionDigits:2,maximumFractionDigits:2}); };
  let html = '<div class="bal-card"><div class="bal-card-head"><div class="bal-card-title">Inventario de Balances</div>'
    + '<div class="bal-card-tag">clasificación por tipo de bien</div></div>';

  keys.forEach(function(tipo) {
    const d = bienStock[tipo];
    const label = BIEN_LABELS[tipo] || tipo;
    const color = BIEN_COLORS[tipo] || 'var(--muted)';
    const pct = bienStock.sin_clasificar && bienStock.sin_clasificar.u > 0 && tipo === 'sin_clasificar' ? '' : '';
    html += '<div style="margin-bottom:14px">'
      + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">'
      +   '<span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:'+color+'"></span>'
      +   '<span style="font-family:var(--font-display);font-size:13px;font-weight:700;color:var(--ink)">'+esc(label)+'</span>'
      +   '<span style="font-size:11px;color:var(--muted);margin-left:auto">'+d.u.toLocaleString('es-AR')+' u'+(d.v>0?' · '+fmt(d.v):'')+'</span>'
      + '</div>'
      + '<div class="bien-items">';
    // Top 5 items by value, rest collapsed
    const sorted = d.items.slice().sort(function(a,b){ return b.valor-a.valor; });
    const show = sorted.slice(0, 5);
    show.forEach(function(it) {
      html += '<div class="bien-item-row">'
        + '<span class="bien-item-name">'+esc(it.n)+'</span>'
        + '<span class="bien-item-qty">'+esc(it.q)+' u'+(it.valor>0?' · '+fmt(it.valor):'')+'</span>'
        + '</div>';
    });
    if (sorted.length > 5) {
      html += '<div style="font-size:10.5px;color:var(--muted);margin-top:4px">…y '+( sorted.length-5)+' más</div>';
    }
    html += '</div></div>';
  });
  html += '</div>';
  return html;
}

// ── Histórico mínimos a fin de año ──────────────────────────────────────────
const LS_YEAR_MIN = 'hds_year_min';
function loadYearMin() { try { return JSON.parse(localStorage.getItem(LS_YEAR_MIN) || '[]'); } catch { return []; } }
function saveYearMin(d) { try { localStorage.setItem(LS_YEAR_MIN, JSON.stringify(d)); } catch {} }

function buildYearMinCard() {
  const year  = new Date().getFullYear();
  const data  = loadYearMin();
  const fmtM  = function(n){ return '$ '+Number(n||0).toLocaleString('es-AR',{minimumFractionDigits:2,maximumFractionDigits:2}); };
  const lastSnap = data.length ? data[data.length-1] : null;

  let rows = data.slice(-6).reverse().map(function(s) {
    return '<div class="bien-item-row">'
      + '<span class="bien-item-name">'+esc(s.fecha)+'</span>'
      + '<span class="bien-item-qty">'+s.unidades.toLocaleString('es-AR')+' u'+(s.valor>0?' · '+fmtM(s.valor):'')+'</span>'
      + '</div>';
  }).join('');

  return '<div class="bal-card"><div class="bal-card-head"><div class="bal-card-title">Histórico mínimos anuales</div>'
    + '<div class="bal-card-tag">'+year+'</div></div>'
    + '<div style="font-size:11.5px;color:var(--muted);margin-bottom:12px">Guardá una instantánea del stock actual para proyectar el cierre de año.</div>'
    + (rows || '<div class="bal-empty">Sin snapshots guardados todavía.</div>')
    + '<button onclick="saveYearMinSnapshot()" style="margin-top:12px;font-family:inherit;font-size:12px;font-weight:700;padding:9px 18px;border:none;border-radius:11px;background:var(--accent);color:#fff;cursor:pointer">📸 Guardar snapshot ahora</button>'
    + '</div>';
}

function saveYearMinSnapshot() {
  if (!canAccess('tomarSnapshotAnual')) {
    showToast({ type:'danger', title:'Sin permiso', msg:'No tenés permiso para guardar snapshots anuales.' }); return;
  }
  let u = 0, v = 0;
  ['n1','n2'].forEach(function(nk) {
    Object.values(CELLS[nk] || {}).forEach(function(arm) {
      Object.values((arm && arm.repisas) || {}).forEach(function(r) {
        (r.items || []).forEach(function(it) {
          u += +it.q || 0;
          if (it.precio != null) v += (+it.q||0) * (+it.precio||0);
        });
      });
    });
  });
  const snaps = loadYearMin();
  snaps.push({ fecha: localToday(), anio: new Date().getFullYear(), unidades: u, valor: +v.toFixed(2) });
  saveYearMin(snaps);
  showToast({ type:'success', title:'Snapshot guardado', msg: 'Stock: '+u+' u · '+'$ '+v.toLocaleString('es-AR',{minimumFractionDigits:2}), duration:4000 });
  renderBal();
}

// ── CSS for bien cards ─────────────────────────────────────────────────────
(function injectBienCss() {
  if (document.getElementById('bien-card-css')) return;
  const s = document.createElement('style');
  s.id = 'bien-card-css';
  s.textContent = '.bien-items{display:flex;flex-direction:column;gap:3px;padding:6px 10px;background:var(--surface2);border-radius:10px}'
    + '.bien-item-row{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:11.5px}'
    + '.bien-item-name{color:var(--text);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}'
    + '.bien-item-qty{color:var(--muted);white-space:nowrap;font-weight:500}';
  document.head.appendChild(s);
})();

// ── CSS for product detail edit ────────────────────────────────────────────
(function injectPdCss() {
  if (document.getElementById('pd-edit-css')) return;
  const s = document.createElement('style');
  s.id = 'pd-edit-css';
  s.textContent = '.pd-edit-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:10px}'
    + '.pd-edit-field{display:flex;flex-direction:column;gap:4px;flex:1;min-width:120px}'
    + '.pd-edit-field label{font-size:10.5px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--muted)}'
    + '.pd-qty-btn{width:32px;height:32px;border:1px solid var(--border2);border-radius:9px;background:var(--surface2);color:var(--text);font-size:18px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .12s}'
    + '.pd-qty-btn:hover{background:var(--accent);color:#fff;border-color:var(--accent)}'
    + '.pd-save-btn{width:100%;padding:10px;border:none;border-radius:11px;background:var(--accent);color:#fff;font-family:inherit;font-size:13px;font-weight:700;cursor:pointer;transition:filter .12s}'
    + '.pd-save-btn:hover{filter:brightness(.9)}'
    + '.pd-action-btn{padding:9px 16px;border:none;border-radius:10px;font-family:inherit;font-size:12.5px;font-weight:700;cursor:pointer;white-space:nowrap;transition:filter .12s;flex-shrink:0}'
    + '.pd-btn-sacar{background:var(--red);color:#fff}'
    + '.pd-btn-agregar{background:var(--green);color:#fff}'
    + '.pd-action-btn:hover{filter:brightness(.88)}';
  document.head.appendChild(s);
})();

const PIE_PALETTE = ['#3B82F6','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#14B8A6','#F97316','#06B6D4','#84CC16','#6366F1','#F43F5E','#22D3EE','#A3E635','#FB923C'];

function _makePieSvg(slices, total, R) {
  // slices: [ [label, value], ... ]
  if (!total || !slices.length) {
    return '<text x="90" y="94" text-anchor="middle" font-size="12" fill="var(--muted)">Sin datos</text>';
  }
  let angle = -Math.PI / 2;
  const cx = 90, cy = 90;
  return slices.map(function([label, val], i) {
    if (val <= 0) return '';
    const sweep = (val / total) * 2 * Math.PI;
    const x1 = cx + R * Math.cos(angle),      y1 = cy + R * Math.sin(angle);
    const x2 = cx + R * Math.cos(angle+sweep), y2 = cy + R * Math.sin(angle+sweep);
    const large = sweep > Math.PI ? 1 : 0;
    const d = 'M'+cx+','+cy+' L'+x1.toFixed(2)+','+y1.toFixed(2)
            + ' A'+R+','+R+' 0 '+large+',1 '+x2.toFixed(2)+','+y2.toFixed(2)+' Z';
    angle += sweep;
    return '<path d="'+d+'" fill="'+PIE_PALETTE[i%PIE_PALETTE.length]+'" opacity="0.88"'
         + ' stroke="var(--surface)" stroke-width="1.5"><title>'+esc(label)+': '+val.toLocaleString('es-AR')+'</title></path>';
  }).join('');
}

function buildPieCard(catStock, bienStock) {
  const cats = Object.entries(catStock || {}).filter(function([,v]){ return v.u > 0; });
  if (!cats.length) return '';
  const fmtM = function(n){ return '$ '+Number(n||0).toLocaleString('es-AR',{minimumFractionDigits:2,maximumFractionDigits:2}); };

  const totalU = cats.reduce(function(s,[,v]){ return s+v.u; }, 0);
  const catsV  = cats.filter(function([,v]){ return v.v > 0; });
  const totalV = catsV.reduce(function(s,[,v]){ return s+v.v; }, 0);

  const svgU = _makePieSvg(cats.map(function([k,v]){ return [k,v.u]; }), totalU, 78);
  const svgV = catsV.length ? _makePieSvg(catsV.map(function([k,v]){ return [k,v.v]; }), totalV, 78) : null;

  function legendItem(label, display, i) {
    return '<div style="display:flex;align-items:center;gap:7px;margin-bottom:5px">'
      + '<span style="width:11px;height:11px;border-radius:3px;flex-shrink:0;background:'+PIE_PALETTE[i%PIE_PALETTE.length]+'"></span>'
      + '<span style="font-size:11px;font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text)">'+esc(label)+'</span>'
      + '<span style="font-size:11px;font-weight:700;color:var(--muted)">'+esc(String(display))+'</span>'
      + '</div>';
  }

  const legU = cats.map(function([k,v],i){ return legendItem(k, v.u.toLocaleString('es-AR')+' u', i); }).join('');
  const legV = catsV.length ? catsV.map(function([k,v],i){ return legendItem(k, fmtM(v.v), i); }).join('') : '';

  const btnStyle = 'font-family:inherit;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;cursor:pointer;';
  const btnOn    = btnStyle+'border:none;background:var(--accent);color:#fff';
  const btnOff   = btnStyle+'border:1px solid var(--border2);background:var(--surface2);color:var(--muted)';

  return '<div class="bal-card">'
    + '<div class="bal-card-head">'
    +   '<div class="bal-card-title">Distribución por categoría</div>'
    +   '<div style="display:flex;gap:6px">'
    +     '<button id="pie-btn-u" style="'+btnOn+'" onclick="setPieMode(&apos;u&apos;)">Unidades</button>'
    +     (svgV ? '<button id="pie-btn-v" style="'+btnOff+'" onclick="setPieMode(&apos;v&apos;)">Valor $</button>' : '')
    +   '</div>'
    + '</div>'
    + '<div class="pie-body">'
    +   '<div class="pie-media">'
    +     '<svg id="pie-svg-u" viewBox="0 0 180 180" width="180" height="180">'+svgU+'</svg>'
    +     (svgV ? '<svg id="pie-svg-v" viewBox="0 0 180 180" width="180" height="180" style="display:none">'+svgV+'</svg>' : '')
    +   '</div>'
    +   '<div class="pie-legend">'
    +     '<div id="pie-leg-u">'+legU+'</div>'
    +     (legV ? '<div id="pie-leg-v" style="display:none">'+legV+'</div>' : '')
    +     '<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--border)">'
    +       '<span id="pie-total" style="font-size:11px;font-weight:700;color:var(--muted)">Total: '+totalU.toLocaleString('es-AR')+' u</span>'
    +     '</div>'
    +   '</div>'
    + '</div>'
    + '</div>';
}

function setPieMode(mode) {
  const get = function(id){ return document.getElementById(id); };
  const btnOn  = 'font-family:inherit;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;cursor:pointer;border:none;background:var(--accent);color:#fff';
  const btnOff = 'font-family:inherit;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;cursor:pointer;border:1px solid var(--border2);background:var(--surface2);color:var(--muted)';
  if (mode === 'u') {
    if (get('pie-btn-u')) get('pie-btn-u').style.cssText = btnOn;
    if (get('pie-btn-v')) get('pie-btn-v').style.cssText = btnOff;
    if (get('pie-svg-u')) get('pie-svg-u').style.display = '';
    if (get('pie-svg-v')) get('pie-svg-v').style.display = 'none';
    if (get('pie-leg-u')) get('pie-leg-u').style.display = '';
    if (get('pie-leg-v')) get('pie-leg-v').style.display = 'none';
  } else {
    if (get('pie-btn-v')) get('pie-btn-v').style.cssText = btnOn;
    if (get('pie-btn-u')) get('pie-btn-u').style.cssText = btnOff;
    if (get('pie-svg-v')) get('pie-svg-v').style.display = '';
    if (get('pie-svg-u')) get('pie-svg-u').style.display = 'none';
    if (get('pie-leg-v')) get('pie-leg-v').style.display = '';
    if (get('pie-leg-u')) get('pie-leg-u').style.display = 'none';
  }
}

function renderBal() {
  const host = DOM.get('balMain');
  if (!host) return;

  // ── Agregados de stock (desde CELLS) — unidades Y valor monetario ──
  let totalUnidades = 0, totalSKU = 0, valorTotal = 0, skuConPrecio = 0;
  const catStock  = {}; // categoría -> { unidades, valor }
  const bienStock = {}; // tipoBien -> { u, v, items[] }
  const prodValor = {}; // nombre de producto -> { unidades, valor }
  ['n1','n2'].forEach(nk => {
    const arms = CELLS[nk] || {};
    Object.values(arms).forEach(arm => {
      const reps = (arm && arm.repisas) || {};
      Object.values(reps).forEach(r => {
        const cat = (r && r.cat) || '—';
        (r.items || []).forEach(it => {
          const q = +it.q || 0;
          const precio = (it.precio != null && !isNaN(+it.precio)) ? +it.precio : null;
          const valor = precio != null ? q * precio : 0;
          totalUnidades += q; totalSKU++;
          if (precio != null) { valorTotal += valor; skuConPrecio++; }
          // Clasificación por tipo de bien
          const tipo = it.tipoBien || 'sin_clasificar';
          if (!bienStock[tipo]) bienStock[tipo] = { u:0, v:0, items:[] };
          bienStock[tipo].u += q; bienStock[tipo].v += valor;
          bienStock[tipo].items.push({ n:it.n, q, valor, cat, nave:nk, precio });
          if (cat !== '—') {
            if (!catStock[cat]) catStock[cat] = { u: 0, v: 0 };
            catStock[cat].u += q;
            catStock[cat].v += valor;
          }
          if (it.n) {
            if (!prodValor[it.n]) prodValor[it.n] = { u: 0, v: 0 };
            prodValor[it.n].u += q;
            prodValor[it.n].v += valor;
          }
        });
      });
    });
  });
  const coberturaPrecio = totalSKU ? Math.round(skuConPrecio / totalSKU * 100) : 0;

  // ── Agregados de movimientos ──
  let ing = 0, egr = 0;
  const perNave = { 'N-1':{ing:0,egr:0}, 'N-2':{ing:0,egr:0} };
  const catFlow = {};    // categoría -> {ing, egr}
  const prodVol = {};    // producto -> volumen total movido
  const catIdx = repCatIndex();
  movs.forEach(m => {
    if (m.tipo === 'edicion') return; // no afecta flujo de stock
    const q = +m.cantidad || 0;
    if (m.tipo === 'ingreso') ing += q; else egr += q;
    if (perNave[m.nave]) perNave[m.nave][m.tipo === 'ingreso' ? 'ing' : 'egr'] += q;
    const cat = (catIdx[m.nave] && catIdx[m.nave][m.armario]) || 'OTROS';
    if (!catFlow[cat]) catFlow[cat] = { ing:0, egr:0 };
    catFlow[cat][m.tipo === 'ingreso' ? 'ing' : 'egr'] += q;
    prodVol[m.producto] = (prodVol[m.producto] || 0) + q;
  });
  const flujoTotal = ing + egr;
  const neto = ing - egr;
  const pIng = flujoTotal ? Math.round(ing / flujoTotal * 100) : 0;
  const pEgr = 100 - pIng;

  // ── Helper de formato monetario ──
  const fmtMoney = (n) => '$ ' + Number(n || 0).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  // ── KPIs ──
  const kpis = `
    <div class="bal-kpis">
      <div class="kpi">
        <div class="kpi-ico"><svg viewBox="0 0 24 24"><path d="M20 7l-8-4-8 4 8 4 8-4z"/><path d="M4 7v10l8 4 8-4V7"/><line x1="12" y1="11" x2="12" y2="21"/></svg></div>
        <div class="kpi-lbl">Unidades en stock</div>
        <div class="kpi-val">${totalUnidades.toLocaleString('es-AR')}</div>
        <div class="kpi-sub">${totalSKU} SKU activos</div>
      </div>
      <div class="kpi">
        <div class="kpi-ico"><svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></div>
        <div class="kpi-lbl">Valor neto del stock</div>
        <div class="kpi-val blue">${fmtMoney(valorTotal)}</div>
        <div class="kpi-sub">${coberturaPrecio}% del stock con precio cargado</div>
      </div>
      <div class="kpi">
        <div class="kpi-ico"><svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg></div>
        <div class="kpi-lbl">Ingresos</div>
        <div class="kpi-val green">${ing.toLocaleString('es-AR')}</div>
        <div class="kpi-sub">unidades recibidas</div>
      </div>
      <div class="kpi">
        <div class="kpi-ico"><svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg></div>
        <div class="kpi-lbl">Egresos</div>
        <div class="kpi-val red">${egr.toLocaleString('es-AR')}</div>
        <div class="kpi-sub">unidades retiradas</div>
      </div>
    </div>`;

  // ── Flujo ingresos vs egresos ──
  const flujoCard = `
    <div class="bal-card">
      <div class="bal-card-head">
        <div class="bal-card-title">Flujo de stock</div>
        <div class="bal-card-tag">${movs.length} movimientos</div>
      </div>
      <div class="flow-split">
        <div class="flow-meter">
          <div class="seg-ing" style="width:${pIng}%"></div>
          <div class="seg-egr" style="width:${pEgr}%"></div>
        </div>
        <div class="flow-legend">
          <span><span class="dot ing"></span>Ingresos ${pIng}% · ${ing}</span>
          <span><span class="dot egr"></span>Egresos ${pEgr}% · ${egr}</span>
        </div>
      </div>
      <div class="bal-net">
        <div class="bal-net-lbl">Resultado neto del período</div>
        <div class="bal-net-val" style="color:${neto>=0?'var(--green)':'var(--red)'}">${neto>=0?'+':''}${neto} u</div>
      </div>
    </div>`;

  // ── Por nave ──
  const maxNave = Math.max(1, perNave['N-1'].ing, perNave['N-1'].egr, perNave['N-2'].ing, perNave['N-2'].egr);
  const naveRow = (lbl, val, cls) => `
    <div class="bar-row">
      <div class="bar-name">${esc(lbl)}</div>
      <div class="bar-track"><div class="bar-fill ${cls}" style="width:${Math.round(val/maxNave*100)}%"></div></div>
      <div class="bar-val">${esc(val)}</div>
    </div>`;
  const naveCard = `
    <div class="bal-card">
      <div class="bal-card-head">
        <div class="bal-card-title">Por nave</div>
        <div class="bal-card-tag">unidades movidas</div>
      </div>
      ${naveRow('N-1 · Ingresos', perNave['N-1'].ing, 'ing')}
      ${naveRow('N-1 · Egresos', perNave['N-1'].egr, 'egr')}
      ${naveRow('N-2 · Ingresos', perNave['N-2'].ing, 'ing')}
      ${naveRow('N-2 · Egresos', perNave['N-2'].egr, 'egr')}
    </div>`;

  // ── Top productos por volumen (unidades movidas) ──
  const topProd = Object.entries(prodVol).sort((a,b)=>b[1]-a[1]).slice(0,6);
  const maxProd = Math.max(1, ...topProd.map(p=>p[1]));
  const prodCard = `
    <div class="bal-card">
      <div class="bal-card-head">
        <div class="bal-card-title">Productos más movidos</div>
        <div class="bal-card-tag">top ${topProd.length}</div>
      </div>
      ${topProd.length ? topProd.map(([n,v])=>`
        <div class="bar-row">
          <div class="bar-name">${esc(n)}</div>
          <div class="bar-track"><div class="bar-fill blue" style="width:${Math.round(v/maxProd*100)}%"></div></div>
          <div class="bar-val">${esc(v)}</div>
        </div>`).join('') : '<div class="bal-empty">Sin movimientos registrados</div>'}
    </div>`;

  // ── Stock por categoría (unidades + valor $) ──
  const cats = Object.entries(catStock).sort((a,b)=>b[1].v-a[1].v);
  const catTotalU = Math.max(1, cats.reduce((s,[,info])=>s+(info.u||0),0)); // base para la share-bar
  const catCard = `
    <div class="bal-card">
      <div class="bal-card-head">
        <div class="bal-card-title">Stock por categoría</div>
        <div class="bal-card-tag">${cats.length} categorías</div>
      </div>
      ${cats.length ? cats.map(([c,info])=>{
        const f = catFlow[c] || {ing:0,egr:0};
        const share = Math.round((info.u||0)/catTotalU*100); // % del stock total (visual)
        return `<div class="cat-row">
          <div style="flex:1;min-width:0">
            <div class="cat-name">${esc(c)}</div>
            <div class="cat-meta">+${esc(f.ing)} / −${esc(f.egr)} en movimientos · ${share}% del stock</div>
            <div class="cat-share" title="${share}% del stock total"><i style="width:${share}%"></i></div>
          </div>
          <div style="text-align:right">
            <div class="cat-val">${esc(info.u)} u</div>
            ${info.v > 0 ? `<div style="font-size:10px;color:var(--accent);font-weight:700;margin-top:2px">${fmtMoney(info.v)}</div>` : ''}
          </div>
        </div>`;
      }).join('') : '<div class="bal-empty">Sin stock cargado por categoría</div>'}
    </div>`;

  // ── Top productos por valor monetario ──
  const topValor = Object.entries(prodValor).filter(([,v]) => v.v > 0).sort((a,b)=>b[1].v-a[1].v).slice(0,6);
  const maxValor = Math.max(1, ...topValor.map(p=>p[1].v));
  const valorCard = `
    <div class="bal-card" style="background:var(--blue-dim);border-color:rgba(13,99,234,.25)">
      <div class="bal-card-head">
        <div class="bal-card-title" style="color:var(--accent)">Top productos por valor</div>
        <div class="bal-card-tag">${fmtMoney(valorTotal)} total</div>
      </div>
      ${topValor.length ? topValor.map(([n,info])=>`
        <div class="bar-row">
          <div class="bar-name">${esc(n)}</div>
          <div class="bar-track"><div class="bar-fill blue" style="width:${Math.round(info.v/maxValor*100)}%"></div></div>
          <div class="bar-val" style="min-width:70px;text-align:right">${fmtMoney(info.v)}</div>
        </div>`).join('')
        : `<div style="font-size:12.5px;color:var(--muted);line-height:1.5;padding:6px 0">
             Ningún producto tiene precio unitario cargado todavía. Agregalo en
             <b>+ Producto</b> (campo "Precio $") para que el valor neto del stock
             se calcule automáticamente acá.
           </div>`}
    </div>`;

  const pieCard  = buildPieCard(catStock, bienStock);
  const bienCard = buildBienCard(bienStock, fmtMoney);
  const yearCard = buildYearMinCard();
  host.innerHTML = kpis
    + `<div class="bal-cols">${flujoCard}${naveCard}</div>`
    + `<div class="bal-cols">${prodCard}${valorCard}</div>`
    + catCard
    + bienCard
    + yearCard
    + pieCard;
}

// ════════════════════════════════════════════════════════════════════════════
// STOCK GENERAL — vista unificada de todos los productos (ambas naves)
// Aplana CELLS → lista con búsqueda + filtro por categoría. Solo lectura,
// no altera el modelo de datos.
// ════════════════════════════════════════════════════════════════════════════
