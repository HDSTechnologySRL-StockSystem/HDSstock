// ═══════════════════════════════════════════════════════
// src/core/router.js
// Navegación SPA: go(), goInicio(), switchNave().
// Depende de: auth.js, shared/toast.js, y cada módulo
//             de pantalla (a través de window.renderXxx)
// ═══════════════════════════════════════════════════════
'use strict';

let _activeNave = null; // 'n1' | 'n2' | null   // último mapa (nave) en el que operó el usuario
function go(id) {
  if (!currentUser && id !== 'login') {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('on'));
    DOM.get('sc-login').classList.add('on');
    return;
  }
  closePopup();
  if (id === 'n1' || id === 'n2') _activeNave = id;   // recordar mapa activo
  else closeAllShelfWindows();                        // al salir de las naves, cerrar ventanas flotantes
  const navGuard = {
    n1:'accesNave1', n2:'accesNave2',
    mov:'accesMovimientos', pet:'accesPeticiones',
    bal:'accesEstadisticas', stock:'accesStockGeneral',
  };
  if (navGuard[id] && !canAccess(navGuard[id])) {
    showToast({ type:'danger', title:'Acceso restringido', msg:'No tenés permiso para acceder a esta sección.' });
    return;
  }
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('on'));
  const map = { home:'sc-home', n1:'sc-n1', n2:'sc-n2', mov:'sc-mov', pet:'sc-pet', bal:'sc-bal', users:'sc-users', stock:'sc-stock' };
  const el = document.getElementById(map[id] || id);
  if (el) el.classList.add('on');
  if (id === 'mov') renderMov();
  if (id === 'pet') renderPet();
  if (id === 'bal') renderBal();
  if (id === 'users') renderUsersPanel();
  if (id === 'stock') renderStock();
}
// Botón "Inicio" de la isla de navegación: vuelve al mapa activo (preserva el flujo).
// Si no hay mapa activo (recién entró), va al home general.
function goInicio() {
  // Si el usuario visitó una nave específica, vuelve a ella directamente.
  // De lo contrario (primer uso o acceso desde login) va al home general.
  if (_activeNave === 'n1' || _activeNave === 'n2') { go(_activeNave); return; }
  go('home');
}
function switchNave() {
  const cur = document.querySelector('.screen.on')?.id;
  if (cur === 'sc-n1') return go('n2');
  if (cur === 'sc-n2') return go('n1');
  return go(_activeNave === 'n2' ? 'n1' : 'n2');   // desde mov/pet/bal: ir a la otra nave
}
function injectNavSwitch() { /* deshabilitado en v2.9 — botón en topbar */ }

// ════════════════════════════════════════════════
// STOCK DATA — per nave
