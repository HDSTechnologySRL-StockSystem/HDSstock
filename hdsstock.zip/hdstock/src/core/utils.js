// ═══════════════════════════════════════════════════════
// src/core/utils.js
// Utilidades globales: sanitización XSS, fechas,
// caché del DOM, helpers varios.
// ═══════════════════════════════════════════════════════
'use strict';

// ════════════════════════════════════════════════
// SEGURIDAD — Sanitización centralizada (XSS)
// ════════════════════════════════════════════════
// esc(): escapa caracteres peligrosos para insertar texto dentro de HTML.
// Usar SIEMPRE que se interpole un valor que provenga de un input del
// usuario (nombre de producto, descripción, nombre de perfil, etc.)
// dentro de un template literal que luego se asigna a innerHTML.
function esc(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
// escAttr(): igual que esc() pero pensado para usar dentro de atributos
// HTML (onclick="...", value="...", title="..."). Evita que el valor
// rompa las comillas del atributo o inyecte un nuevo atributo/evento.
function escAttr(str) { return esc(str); }

// ════════════════════════════════════════════════
// CACHÉ DEL DOM — evita re-consultas repetidas a getElementById
// ════════════════════════════════════════════════
// DOM.get(id): primera vez consulta y guarda; siguientes veces devuelve
// del cache. Se usa para elementos que se consultan MUCHAS veces durante
// la sesión (topbar, popup de celda, botones de login, etc.) y que
// existen desde el arranque (no se destruyen/recrean dinámicamente).
// Para elementos creados/destruidos en runtime (filas de tabla, chips,
// ventanas flotantes) seguimos usando getElementById/querySelector
// directo, porque cachearlos daría referencias colgantes.
// ════════════════════════════════════════════════
// FECHAS — formateo en hora LOCAL (no UTC)
// ════════════════════════════════════════════════
// localISODate(d?): devuelve 'YYYY-MM-DD' usando la hora LOCAL del
// navegador, NO new Date().toISOString() que está en UTC y puede dar
// el día equivocado según el huso horario (ej. en Argentina, UTC-3,
// pasadas las 21:00 locales ya es "mañana" en UTC).
function localISODate(d) {
  const date = d ? new Date(d) : new Date();
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + day;
}
// localToday(): atajo para "hoy" en formato YYYY-MM-DD, hora local.
function localToday() { return localISODate(); }
// localDateTime(): 'YYYY-MM-DD HH:mm' en hora local, para timestamps de eventos.
function localDateTime(d) {
  const date = d ? new Date(d) : new Date();
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return localISODate(date) + ' ' + hh + ':' + mm;
}
// addDaysISO(isoDate, n): suma n días a una fecha ISO, devuelve ISO local.
function addDaysISO(isoDate, n) {
  const d = new Date(isoDate + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return localISODate(d);
}

const DOM = (() => {
  const cache = new Map();
  return {
    get(id) {
      if (cache.has(id)) {
        const el = cache.get(id);
        // Verificar que el nodo sigue en el documento (por si se recreó)
        if (el && document.contains(el)) return el;
        cache.delete(id);
      }
      const el = document.getElementById(id);
      if (el) cache.set(id, el);
      return el;
    },
    clear(id) { if (id) cache.delete(id); else cache.clear(); },
  };
})();


let currentUser = null;        // nombre de usuario (string)
let currentRol  = '';          // Operario | Supervisor | Encargado | Administrador
let currentSede = '';          // HDS | Fiat | JAMA | Fiat-Sevel | Volkswagen | Otra

function naveLbl(n){ return n === 'n1' ? 'N-1' : 'N-2'; }
function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
function cssAttr(s){ return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
function ensureItemId(item){
  if (!item.id) item.id = 'SKU-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2,5).toUpperCase();
  return item.id;
}
// Atributos personalizados en el form Nuevo Producto
function npResetMeta(){ const c=document.getElementById('np-meta-rows'); if(c) c.innerHTML=''; }
function fillSelect(sel, values, makeLabel) {
  if (!sel) return;
  sel.innerHTML = values.map(v => `<option value="${esc(v)}">${esc(makeLabel?makeLabel(v):v)}</option>`).join('');
}

// ── NUEVO PRODUCTO (global, desde el +) ───────────────────────────────────────
function cssEsc(s){ try { return (window.CSS&&CSS.escape)?CSS.escape(s):s.replace(/([^\w-])/g,'\\$1'); } catch { return s; } }
