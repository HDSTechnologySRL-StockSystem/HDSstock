// ═══════════════════════════════════════════════════════
// src/core/stockBus.js
// Bus de eventos para mutaciones de stock.
// Punto único de ingreso/egreso → registra mov + re-render.
// Depende de: movimientos.js (logMovConPrecio, saveMovs)
// ═══════════════════════════════════════════════════════
'use strict';

const StockBus = (function() {
  const _handlers = [];

  function emit(tipo, payload) {
    const { item, cantidad, cid, rid, nave, precio } = payload;
    const naveLabel  = nave === 'n1' ? 'N-1' : 'N-2';
    const precioUnit = precio != null ? +precio
                      : (item && item.precio != null ? +item.precio : null);

    // ── 1. Persistencia ───────────────────────────────────────────────────────
    if (tipo !== 'precio') {
      // logMovConPrecio ya hace unshift + saveMovs
      logMovConPrecio(
        tipo,
        item.n,
        cantidad,
        cid + '-' + rid,
        naveLabel,
        currentSignature(),
        localToday(),
        currentSede,
        precioUnit
      );
    } else {
      // Cambio de precio: solo persistir CELLS (ya mutado por el llamador)
      saveCells();
    }

    // ── 2. Render reactivo inmediato ─────────────────────────────────────────
    // Movimientos: solo re-render si la pantalla está visible
    if (document.getElementById('sc-mov')?.classList.contains('on')) {
      renderMov();
    }
    // Balances: idem
    if (document.getElementById('sc-bal')?.classList.contains('on')) {
      renderBal();
    }
    // Stock General: idem — se actualiza al borrar/agregar/mover productos
    if (document.getElementById('sc-stock')?.classList.contains('on')) {
      renderStock();
    }
    // Ventana flotante del estante (si está abierta para ese armario)
    if (cid && nave) refreshShelfWindow(nave, cid);

    // ── 3. Notificar handlers externos (extensible) ───────────────────────────
    _handlers.forEach(function(h) { try { h(tipo, payload); } catch(e) {} });
  }

  return {
    emit:   emit,
    on:     function(fn) { _handlers.push(fn); },  // hook para extensiones futuras
  };
})();
