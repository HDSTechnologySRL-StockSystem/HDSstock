// ═══════════════════════════════════════════════════════
// src/core/bootstrap.js
// Punto de entrada: inicializa la app al cargar la página.
// Orden: inyectar HTML → seed → tema → datos → sesión → pantalla
// ═══════════════════════════════════════════════════════
'use strict';

function bootstrap() {
  // 0) Crear cuenta Admin por defecto si no existe ningún usuario todavía
  _seedAdminIfNeeded();

  // 1) Tema (modo oscuro)
  applyTheme(localStorage.getItem('hds_theme') === 'dark');
  injectNavSwitch();    // botón "Cambiar nave" en todas las barras
  enhanceA11y();         // role="button" + tabindex en celdas SVG y nave-cards
  applyNaveNames();      // nombres personalizados de naves

  // 2) Datos persistidos
  loadCellsInto();
  // Migración v2.9.1: limpiar items de ejemplo hardcodeados que pueden haber
  // quedado guardados en localStorage de versiones anteriores.
  _migrateWipeExampleItems();
  loadMovs();
  try { restoreShelves(); } catch(e){ console.warn('restoreShelves', e); }
  // Aplicar nombres personalizados a todos los estantes (estáticos + dinámicos)
  _applyAllShelfNames();

  // 3) Sesión persistida → entrar directo sin volver a loguear
  const sess = loadSession();
  if (sess && sess.user) {
    const prof = getProfile(sess.user);
    if (prof) {
      currentUser = sess.user;
      currentRol  = sess.rol  || prof.rol  || 'Operario';
      currentSede = sess.sede || prof.sede || 'HDS';
      updateUserChip();
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('on'));
      document.getElementById('sc-home').classList.add('on');
      setTimeout(() => { try{ updateNavBadges(); checkDeadlines(); surfaceAccessRequests(); }catch(e){} }, 600);
      // Splash fuera rápido cuando ya hay sesión
      setTimeout(dismissWelcome, 700);
      return;
    }
  }
  setTimeout(dismissWelcome, 1900);
}
window.addEventListener('load', bootstrap);

// ════════════════════════════════════════════════
// BALANCES / ESTADÍSTICAS
// ════════════════════════════════════════════════
function repCatIndex() {
  // mapea id de repisa (ej "A1") -> categoría, por nave
  const idx = { 'N-1':{}, 'N-2':{} };
  ['n1','n2'].forEach(nk => {
    const nv = nk === 'n1' ? 'N-1' : 'N-2';
    const arms = CELLS[nk] || {};
    Object.values(arms).forEach(arm => {
      const reps = (arm && arm.repisas) || {};
      Object.entries(reps).forEach(([rid, r]) => {
        if (r && r.cat && r.cat !== '—') idx[nv][rid] = r.cat;
      });
    });
  });
  return idx;
}


// ════════════════════════════════════════════════
// PIE CHART SVG — categorías por unidades y por valor
// SVG puro, sin dependencias externas.
// ════════════════════════════════════════════════

// ════════════════════════════════════════════════
// BALANCES — Bienes de Cambio/Uso + Año histórico
// ════════════════════════════════════════════════

