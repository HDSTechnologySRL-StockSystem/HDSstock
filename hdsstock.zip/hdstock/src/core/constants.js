// ═══════════════════════════════════════════════════════
// src/core/constants.js
// Todas las constantes globales de la aplicación HDS Stock
// ═══════════════════════════════════════════════════════
'use strict';

const HDS_VERSION = '2.9';
const LS_KEYS = {
  users:      'hds_users',
  session:    'hds_session',
  cells:      'hds_cells',
  movs:       'hds_movs',
  shelfGeom:  'hds_shelf_geom',
  cellStyles: 'hds_cell_styles',
  accessReqs: 'hds_access_reqs',
  pendingRegs:'hds_pending_regs',
  theme:      'hds_dark',
  pets:       'hds_pets',
  naveNames:  'hds_nave_names',
};
const ROLES = ['Operario', 'Supervisor', 'Encargado', 'Administrador'];
const SEDES = ['HDS', 'Fiat', 'JAMA', 'Fiat-Sevel', 'Volkswagen', 'Otra'];
const PERMS_CATALOG = [
  // ── Navegación ──────────────────────────────────────────────────────────
  { key:'accesNave1',          label:'Acceso a Nave 1',                group:'nav'   },
  { key:'accesNave2',          label:'Acceso a Nave 2',                group:'nav'   },
  { key:'accesMovimientos',    label:'Acceso a Movimientos',           group:'nav'   },
  { key:'accesPeticiones',     label:'Acceso a Peticiones',            group:'nav'   },
  { key:'accesEstadisticas',   label:'Acceso a Estadísticas',          group:'nav'   },
  { key:'accesStockGeneral',   label:'Acceso a Stock General',         group:'nav'   },
  { key:'accesUsuarios',       label:'Acceso a Gestión de Usuarios',   group:'nav'   },

  // ── Stock / Inventario ──────────────────────────────────────────────────
  { key:'verStock',            label:'Ver stock de estantes',          group:'stock' },
  { key:'sumarStock',          label:'Sumar stock (ingreso)',          group:'stock' },
  { key:'restarStock',         label:'Restar stock (egreso)',          group:'stock' },
  { key:'modificarStock',      label:'Editar nombre / cantidad',       group:'stock' },
  { key:'agregarProductos',    label:'Agregar nuevos productos',       group:'stock' },
  { key:'eliminarProductos',   label:'Eliminar productos',             group:'stock' },
  { key:'verPrecios',          label:'Ver precios unitarios',          group:'stock' },
  { key:'editarPrecios',       label:'Editar precios unitarios',       group:'stock' },
  { key:'verQR',               label:'Ver / imprimir QR',              group:'stock' },

  // ── Estantes / Plano ────────────────────────────────────────────────────
  { key:'crearEstantes',       label:'Crear nuevos estantes',          group:'shelf' },
  { key:'moverEstantes',       label:'Mover estantes en el plano',     group:'shelf' },
  { key:'rotarEstantes',       label:'Rotar estantes',                 group:'shelf' },
  { key:'colorEstantes',       label:'Cambiar color de estantes',      group:'shelf' },
  { key:'borrarEstantes',      label:'Borrar estantes',                group:'shelf' },
  { key:'renombrarEstantes',   label:'Renombrar armarios',             group:'shelf' },
  { key:'renombrarNaves',      label:'Renombrar naves',                group:'shelf' },
  { key:'editarCategorias',    label:'Editar categorías de repisas',   group:'shelf' },

  // ── Movimientos ─────────────────────────────────────────────────────────
  { key:'verMovimientos',      label:'Ver historial completo',         group:'movs'  },
  { key:'exportarMovimientos', label:'Exportar movimientos (CSV)',     group:'movs'  },
  { key:'borrarMovimientos',   label:'Limpiar / borrar movimientos',   group:'movs'  },

  // ── Peticiones ──────────────────────────────────────────────────────────
  { key:'hacerPeticiones',     label:'Crear peticiones de compra',     group:'pet'   },
  { key:'aprobarPeticiones',   label:'Aprobar / rechazar peticiones',  group:'pet'   },
  { key:'borrarPeticiones',    label:'Eliminar peticiones',            group:'pet'   },
  { key:'verTodasPeticiones',  label:'Ver peticiones de todos',        group:'pet'   },

  // ── Balances ────────────────────────────────────────────────────────────
  { key:'verBalances',         label:'Ver estadísticas y KPIs',        group:'bal'   },
  { key:'verHistoricoAnual',   label:'Ver histórico anual de mínimos', group:'bal'   },
  { key:'tomarSnapshotAnual',  label:'Tomar snapshot anual',           group:'bal'   },

  // ── Usuarios ────────────────────────────────────────────────────────────
  { key:'aprobarUsuarios',     label:'Aprobar / rechazar cuentas',     group:'usr'   },
  { key:'eliminarUsuarios',    label:'Eliminar usuarios',              group:'usr'   },
  { key:'cambiarRoles',        label:'Cambiar roles',                  group:'usr'   },
  { key:'editarPermisos',      label:'Editar permisos de usuarios',    group:'usr'   },
];

const PERMS_GROUPS = {
  nav:   '🗺 Navegación',
  stock: '📦 Stock e Inventario',
  shelf: '🏗 Estantes y Plano',
  movs:  '🔄 Movimientos',
  pet:   '📋 Peticiones',
  bal:   '📊 Balances',
  usr:   '👤 Usuarios',
};


// ── Stock ──────────────────────────────────────────────
const STOCK_MIN_DEFAULT = 3;  // umbral global si el item no tiene stockMin propio

// ── Plano SVG ──────────────────────────────────────────
const GRID       = 20;  // tamaño snap-grid en unidades SVG
const CM_PER_SVG = 1;   // 1 cm = 1 unidad SVG

// ── Dimensiones mínimas de estante ────────────────────
const SHELF_MIN_W = 40;
const SHELF_MIN_H = 30;

// ── Colores para gráfico de torta ─────────────────────
const PIE_PALETTE = ['#3B82F6','#10B981','#F59E0B','#EF4444','#8B5CF6',
  '#EC4899','#14B8A6','#F97316','#06B6D4','#84CC16',
  '#6366F1','#F43F5E','#22D3EE','#A3E635','#FB923C'];

// ── Etiquetas de bienes (Balances) ────────────────────
const BIEN_LABELS = {
  cambio:         'Bienes de Cambio',
  uso:            'Bienes de Uso / Patrimonial',
  sin_clasificar: 'Sin clasificar',
};
const BIEN_COLORS = {
  cambio:         'var(--accent)',
  uso:            'var(--amber, #F59E0B)',
  sin_clasificar: 'var(--muted)',
};

// ── Items de ejemplo a eliminar en migración ──────────
const _EXAMPLE_ITEM_NAMES = new Set([
  'TORNILLOS','BULONES','TUERCAS','ARANDELAS',
  'ROD 6205','ROD 6304','ROD 6001',
  'LLAVE ALLEN 6','LLAVE ALLEN 8','DEST PH2',
]);

// ── Config de email (activar provider para producción) ─
const HDS_EMAIL_CONFIG = {
  provider:         'console',   // 'console' | 'emailjs' | 'custom'
  emailjsServiceId:  'TU_SERVICE_ID',
  emailjsTemplateId: 'TU_TEMPLATE_ID',
  emailjsPublicKey:  'TU_PUBLIC_KEY',
  customEndpoint:    'https://tu-api.com/send-code',
};
